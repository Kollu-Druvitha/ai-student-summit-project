import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from './components/Navbar';
import HeroScanner from './components/HeroScanner';
import OverviewDashboard from './components/OverviewDashboard';
import BreachResults from './components/BreachResults';
import DataExposureBreakdown from './components/DataExposureBreakdown';
import RiskTrendGraph from './components/RiskTrendGraph';
import PasswordInsights from './components/PasswordInsights';
import AlertCenter from './components/AlertCenter';
import PrivacyChecklist from './components/PrivacyChecklist';
import MonitoringToggle from './components/MonitoringToggle';
import DigitalFootprint from './components/DigitalFootprint';
import AccountActivity from './components/AccountActivity';
import Footer from './components/Footer';
import { mockBreaches } from './lib/mockData';

function App() {
  const [currentResult, setCurrentResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isMonitoring, setIsMonitoring] = useState(false);

  const handleScan = async (email) => {
    setLoading(true);
    try {
      // Try real API first
      const response = await fetch(`http://127.0.0.1:8000/check/${encodeURIComponent(email)}`);
      const data = await response.json();
      setCurrentResult(data);
    } catch (error) {
      console.log('Using mock data (backend not reachable)');
      // Fallback to mock data
      const mockResult = mockBreaches[email] || {
        found_in_breaches: false,
        breach_count: 0,
        breaches: [],
        risk_level: "LOW",
        risk_score: 0
      };
      setCurrentResult({ ...mockResult, email });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cyber-900">
      {/* Background Grid Pattern */}
      <div className="fixed inset-0 bg-grid-pattern opacity-30 pointer-events-none animate-grid-move" />
      
      {/* Main Content */}
      <div className="relative z-10">
        <Navbar />
        
        <main className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 space-y-6">
          {/* Hero Scanner */}
          <HeroScanner onScan={handleScan} loading={loading} result={currentResult} />

          {/* Overview Dashboard */}
          <OverviewDashboard result={currentResult} isMonitoring={isMonitoring} />

          {/* Main Grid - 3 columns */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - 2 cols */}
            <div className="lg:col-span-2 space-y-6">
              {currentResult?.found_in_breaches && <BreachResults result={currentResult} />}
              <DataExposureBreakdown result={currentResult} />
              <RiskTrendGraph />
            </div>

            {/* Right Column - 1 col */}
            <div className="space-y-6">
              <PasswordInsights />
              <DigitalFootprint />
            </div>
          </div>

          {/* Second Row - 2 columns */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AlertCenter />
            <PrivacyChecklist />
          </div>

          {/* Third Row - Full Width */}
          <AccountActivity />
          
          {/* Monitoring Toggle */}
          <MonitoringToggle 
            isMonitoring={isMonitoring} 
            onToggle={() => setIsMonitoring(!isMonitoring)} 
          />
        </main>

        <Footer />
      </div>
    </div>
  );
}

export default App;