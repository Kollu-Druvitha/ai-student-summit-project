import React from 'react';
import { Database, Mail, Lock, Phone, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { exposureData } from '../lib/mockData';

const DataExposureBreakdown = ({ result }) => {
  const getExposureData = () => {
    if (result?.breaches) {
      // Calculate real exposure based on breaches
      const exposed = {
        emails: result.breaches.some(b => b.data_leaked.includes('email')) ? 1 : 0,
        passwords: result.breaches.filter(b => b.data_leaked.includes('password')).length,
        phones: result.breaches.filter(b => b.data_leaked.includes('phone')).length,
        personal: result.breaches.filter(b => 
          b.data_leaked.some(d => ['name', 'address', 'dob'].includes(d))
        ).length,
      };
      
      return [
        { type: 'Emails Exposed', count: exposed.emails, icon: Mail, color: '#00C2FF' },
        { type: 'Password Leaks', count: exposed.passwords, icon: Lock, color: '#FF4D6D' },
        { type: 'Phone Numbers', count: exposed.phones, icon: Phone, color: '#FFB347' },
        { type: 'Personal Data', count: exposed.personal, icon: User, color: '#9D4EDD' },
      ];
    }
    
    return exposureData.map(item => ({
      ...item,
      icon: item.type.includes('Email') ? Mail :
            item.type.includes('Password') ? Lock :
            item.type.includes('Phone') ? Phone : User
    }));
  };

  const data = getExposureData();

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <Database className="w-5 h-5 text-cyber-blue" />
        Data Exposure Breakdown
      </h3>

      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <item.icon className="w-4 h-4" style={{ color: item.color }} />
                <span className="text-gray-300">{item.type}</span>
              </div>
              <span className="font-mono font-bold" style={{ color: item.color }}>
                {item.count}/{item.total}
              </span>
            </div>
            
            <div className="relative h-2 bg-cyber-900 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(item.count / item.total) * 100}%` }}
                transition={{ duration: 1, delay: index * 0.1 }}
                className="absolute inset-y-0 left-0 rounded-full"
                style={{ backgroundColor: item.color }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="mt-6 pt-4 border-t border-cyber-700">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">Total Exposed Records</span>
          <span className="text-2xl font-bold text-white">
            {data.reduce((acc, item) => acc + item.count, 0)}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default DataExposureBreakdown;