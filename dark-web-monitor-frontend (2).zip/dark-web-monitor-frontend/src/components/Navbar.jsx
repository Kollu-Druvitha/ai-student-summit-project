import React, { useState } from 'react';
import { Shield, Activity, User, Bell, ChevronDown, Settings, LogOut, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const Navbar = () => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="glass-premium mx-4 md:mx-6 lg:mx-8 mt-4 px-6 py-3"
    >
      <div className="flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Shield className="w-8 h-8 text-cyber-blue" />
            <motion.div 
              className="absolute inset-0 bg-cyber-blue/20 blur-xl"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0.8, 0.5]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              Dark Web Monitor
              <span className="text-xs bg-cyber-blue/20 text-cyber-blue px-2 py-0.5 rounded-full">
                Enterprise
              </span>
            </h1>
            <p className="text-xs text-gray-500">Advanced Threat Intelligence Platform</p>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-4">
          {/* Status Indicator */}
          <div className="hidden md:flex items-center gap-3 mr-4">
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="w-2.5 h-2.5 bg-cyber-green rounded-full animate-pulse"></div>
                <div className="absolute inset-0 bg-cyber-green/50 blur-sm animate-pulse"></div>
              </div>
              <div>
                <p className="text-sm text-gray-300">System Active</p>
                <p className="text-xs text-gray-600">24/7 Monitoring</p>
              </div>
            </div>
            <div className="h-8 w-px bg-cyber-700"></div>
          </div>
          
          {/* Notifications */}
          <div className="relative">
            <button 
              className="p-2 hover:bg-cyber-700 rounded-lg transition-colors relative"
              onClick={() => setShowNotifications(!showNotifications)}
            >
              <Bell size={18} className="text-gray-400" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-cyber-red rounded-full"></span>
              <span className="absolute top-1 right-1 w-2 h-2 bg-cyber-red rounded-full animate-ping"></span>
            </button>

            {/* Notifications Dropdown */}
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute right-0 mt-2 w-80 glass-premium p-4 z-50"
              >
                <h4 className="text-sm font-semibold text-white mb-3">Notifications</h4>
                <div className="space-y-3">
                  <div className="p-3 bg-cyber-red/5 rounded-lg border border-cyber-red/30">
                    <p className="text-xs text-cyber-red font-medium">Critical Alert</p>
                    <p className="text-xs text-gray-400 mt-1">New credential dump detected</p>
                    <p className="text-xs text-gray-600 mt-1">2 min ago</p>
                  </div>
                  <div className="p-3 bg-cyber-blue/5 rounded-lg border border-cyber-blue/30">
                    <p className="text-xs text-cyber-blue font-medium">Scan Complete</p>
                    <p className="text-xs text-gray-400 mt-1">Security scan finished</p>
                    <p className="text-xs text-gray-600 mt-1">1 hour ago</p>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* User Menu */}
          <div className="relative">
            <button 
              className="flex items-center gap-3 p-2 hover:bg-cyber-700 rounded-lg transition-colors"
              onClick={() => setShowUserMenu(!showUserMenu)}
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-cyber-blue to-cyber-green 
                            flex items-center justify-center text-white font-bold text-sm">
                SA
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-sm font-medium text-white">Security Admin</p>
                <p className="text-xs text-gray-500">admin@darkmonitor.com</p>
              </div>
              <ChevronDown size={16} className="text-gray-500" />
            </button>

            {/* User Dropdown */}
            {showUserMenu && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute right-0 mt-2 w-56 glass-premium p-2 z-50"
              >
                <div className="px-3 py-2 border-b border-cyber-700">
                  <p className="text-sm text-white">Security Admin</p>
                  <p className="text-xs text-gray-500">Enterprise License</p>
                </div>
                <div className="py-2">
                  <button className="w-full px-3 py-2 text-sm text-gray-300 hover:bg-cyber-700 rounded-lg flex items-center gap-2">
                    <User size={14} /> Profile
                  </button>
                  <button className="w-full px-3 py-2 text-sm text-gray-300 hover:bg-cyber-700 rounded-lg flex items-center gap-2">
                    <Settings size={14} /> Settings
                  </button>
                  <button className="w-full px-3 py-2 text-sm text-gray-300 hover:bg-cyber-700 rounded-lg flex items-center gap-2">
                    <HelpCircle size={14} /> Help
                  </button>
                </div>
                <div className="pt-2 border-t border-cyber-700">
                  <button className="w-full px-3 py-2 text-sm text-cyber-red hover:bg-cyber-red/10 rounded-lg flex items-center gap-2">
                    <LogOut size={14} /> Logout
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Stats Bar */}
      <div className="flex items-center gap-6 mt-3 pt-3 border-t border-cyber-700/50 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-gray-600">Last Scan:</span>
          <span className="text-cyber-green">2 minutes ago</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-600">Threats Blocked:</span>
          <span className="text-white">1,234</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-600">Active Sessions:</span>
          <span className="text-white">3</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-600">Endpoint Protection:</span>
          <span className="text-cyber-green">● Active</span>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;