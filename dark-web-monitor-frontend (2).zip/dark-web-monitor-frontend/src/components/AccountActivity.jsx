import React from 'react';
import { Activity, Smartphone, Laptop, Globe, Lock, AlertCircle, CheckCircle, Clock, MapPin, Chrome } from 'lucide-react';
import { motion } from 'framer-motion';
import { accountActivity } from '../lib/mockData';

const AccountActivity = () => {
  const getActivityIcon = (item) => {
    if (item.icon === 'warning') return <AlertCircle className="w-4 h-4 text-cyber-red" />;
    if (item.icon === 'lock') return <Lock className="w-4 h-4 text-cyber-blue" />;
    return <CheckCircle className="w-4 h-4 text-cyber-green" />;
  };

  const getDeviceIcon = (device) => {
    if (device.toLowerCase().includes('iphone') || device.toLowerCase().includes('mobile')) {
      return <Smartphone className="w-4 h-4" />;
    }
    if (device.toLowerCase().includes('ipad')) {
      return <Laptop className="w-4 h-4" />;
    }
    return <Laptop className="w-4 h-4" />;
  };

  const getBrowserIcon = (browser) => {
    return <Chrome className="w-4 h-4" />;
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <Activity className="w-5 h-5 text-cyber-blue" />
        Account Security Activity
      </h3>

      {/* Activity Timeline */}
      <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
        {accountActivity.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            className="timeline-item"
          >
            {/* Icon */}
            <div className={`p-2 rounded-lg ${
              item.status === 'suspicious' ? 'bg-cyber-red/10' : 
              item.status === 'security' ? 'bg-cyber-blue/10' : 'bg-cyber-green/10'
            }`}>
              {getActivityIcon(item)}
            </div>

            {/* Content */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-medium text-white">
                  {item.type === 'login' ? 'New Login Detected' : 
                   item.type === 'alert' ? '⚠ Suspicious Activity' : '🔒 Password Changed'}
                </p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  item.status === 'suspicious' 
                    ? 'bg-cyber-red/10 text-cyber-red border border-cyber-red/30'
                    : item.status === 'security'
                    ? 'bg-cyber-blue/10 text-cyber-blue border border-cyber-blue/30'
                    : 'bg-cyber-green/10 text-cyber-green border border-cyber-green/30'
                }`}>
                  {item.status === 'suspicious' ? 'Flagged' : 
                   item.status === 'security' ? 'Security' : 'Verified'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mt-2">
                <div className="flex items-center gap-1">
                  {getDeviceIcon(item.device)}
                  <span className="truncate">{item.device}</span>
                </div>
                <div className="flex items-center gap-1">
                  {getBrowserIcon(item.browser)}
                  <span className="truncate">{item.browser}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin size={12} />
                  <span className="truncate">{item.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Globe size={12} />
                  <span className="truncate">{item.ip}</span>
                </div>
                <div className="flex items-center gap-1 col-span-2">
                  <Clock size={12} />
                  <span>{item.time}</span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* View All Link */}
      <button className="w-full mt-4 text-center text-sm text-cyber-blue hover:text-cyber-blue/80 py-2 
                         border-t border-cyber-700 transition-colors">
        View Complete Activity Log →
      </button>
    </motion.div>
  );
};

export default AccountActivity;