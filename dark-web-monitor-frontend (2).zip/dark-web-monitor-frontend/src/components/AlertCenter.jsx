import React, { useState } from 'react';
import { Bell, AlertTriangle, Info, X, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { securityAlerts } from '../lib/mockData';

const AlertCenter = () => {
  const [alerts, setAlerts] = useState(securityAlerts);
  const [showAll, setShowAll] = useState(false);

  const dismissAlert = (id) => {
    setAlerts(alerts.filter(alert => alert.id !== id));
  };

  const getSeverityIcon = (severity) => {
    switch(severity) {
      case 'high': return <AlertTriangle className="w-4 h-4 text-cyber-red" />;
      case 'medium': return <AlertTriangle className="w-4 h-4 text-cyber-amber" />;
      default: return <Info className="w-4 h-4 text-cyber-blue" />;
    }
  };

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'high': return 'border-cyber-red/30 bg-cyber-red/5';
      case 'medium': return 'border-cyber-amber/30 bg-cyber-amber/5';
      default: return 'border-cyber-blue/30 bg-cyber-blue/5';
    }
  };

  const displayedAlerts = showAll ? alerts : alerts.slice(0, 3);

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="glass-premium p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="section-header !border-none !mb-0">
          <Bell className="w-5 h-5 text-cyber-blue" />
          Alert Center
          {alerts.length > 0 && (
            <span className="ml-2 px-2 py-0.5 text-xs bg-cyber-red/20 text-cyber-red rounded-full">
              {alerts.length} new
            </span>
          )}
        </h3>
        <button 
          onClick={() => setShowAll(!showAll)}
          className="text-xs text-cyber-blue hover:text-cyber-blue/80"
        >
          {showAll ? 'Show Less' : 'View All'}
        </button>
      </div>

      <div className="space-y-3">
        <AnimatePresence>
          {displayedAlerts.map((alert) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className={`alert-card ${getSeverityColor(alert.severity)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  {getSeverityIcon(alert.severity)}
                  <div>
                    <h4 className="text-sm font-medium text-white">{alert.title}</h4>
                    <p className="text-xs text-gray-500 mt-1">{alert.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-cyber-blue">{alert.source}</span>
                      <span className="text-xs text-gray-600">•</span>
                      <span className="text-xs text-gray-500">{alert.time}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => dismissAlert(alert.id)}
                  className="p-1 hover:bg-cyber-700 rounded transition-colors"
                >
                  <X size={14} className="text-gray-500" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {alerts.length === 0 && (
        <div className="text-center py-8">
          <CheckCircle className="w-12 h-12 text-cyber-green mx-auto mb-3 opacity-50" />
          <p className="text-gray-500">No active alerts</p>
          <p className="text-xs text-gray-600 mt-1">Your account is secure</p>
        </div>
      )}
    </motion.div>
  );
};

export default AlertCenter;