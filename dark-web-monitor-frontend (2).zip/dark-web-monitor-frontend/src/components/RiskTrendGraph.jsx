import React from 'react';
import { TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { riskTrendData } from '../lib/mockData';

const RiskTrendGraph = () => {
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-cyber-800 border border-cyber-700 rounded-lg p-3 shadow-premium">
          <p className="text-sm text-gray-300">{label}</p>
          <p className="text-lg font-bold text-cyber-blue">
            Risk Score: {payload[0].value}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <TrendingUp className="w-5 h-5 text-cyber-blue" />
        Security Risk Trend
      </h3>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={riskTrendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1F2A41" />
            <XAxis 
              dataKey="month" 
              stroke="#6B7280"
              tick={{ fill: '#9CA3AF', fontSize: 12 }}
            />
            <YAxis 
              stroke="#6B7280"
              tick={{ fill: '#9CA3AF', fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="score" 
              stroke="#00C2FF" 
              strokeWidth={3}
              dot={{ fill: '#00C2FF', strokeWidth: 2 }}
              activeDot={{ r: 8, fill: '#00FF9C' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Insights */}
      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="p-3 bg-cyber-900 rounded-lg">
          <p className="text-xs text-gray-500">Lowest Risk</p>
          <p className="text-lg font-bold text-cyber-green">38</p>
          <p className="text-xs text-gray-600">August 2024</p>
        </div>
        <div className="p-3 bg-cyber-900 rounded-lg">
          <p className="text-xs text-gray-500">Improvement</p>
          <p className="text-lg font-bold text-cyber-blue">27%</p>
          <p className="text-xs text-gray-600">Last 3 months</p>
        </div>
      </div>
    </motion.div>
  );
};

export default RiskTrendGraph;