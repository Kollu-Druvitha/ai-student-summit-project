import React, { useState, useEffect } from 'react';
import { Play, Pause, Activity, Shield, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const MonitoringToggle = ({ isMonitoring, onToggle }) => {
  const [scanMessage, setScanMessage] = useState('');

  const messages = [
    'Scanning dark web forums...',
    'Checking breach databases...',
    'Analyzing threat intelligence...',
    'Monitoring paste sites...',
    'Tracking credential leaks...',
  ];

  useEffect(() => {
    if (isMonitoring) {
      const interval = setInterval(() => {
        setScanMessage(messages[Math.floor(Math.random() * messages.length)]);
      }, 3000);
      
      setScanMessage(messages[0]);
      
      return () => clearInterval(interval);
    }
  }, [isMonitoring]);

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 0.7 }}
      className="glass-premium p-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Continuous Monitoring</h3>
          <p className="text-sm text-gray-500 mt-1">
            Real-time breach intelligence monitoring
          </p>
        </div>
        
        <button
          onClick={onToggle}
          className={`relative flex items-center gap-3 px-6 py-3 rounded-xl font-semibold
                     transition-all duration-300 overflow-hidden
                     ${isMonitoring 
                       ? 'bg-cyber-green/10 text-cyber-green border border-cyber-green/30 hover:shadow-glow-green' 
                       : 'bg-cyber-blue/10 text-cyber-blue border border-cyber-blue/30 hover:shadow-glow-blue'}`}
        >
          <motion.div
            className="absolute inset-0"
            animate={{
              background: isMonitoring 
                ? ['rgba(0,255,156,0)', 'rgba(0,255,156,0.1)', 'rgba(0,255,156,0)']
                : ['rgba(0,194,255,0)', 'rgba(0,194,255,0.1)', 'rgba(0,194,255,0)']
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          
          {isMonitoring ? (
            <>
              <Pause size={18} />
              <span>Stop Monitoring</span>
            </>
          ) : (
            <>
              <Play size={18} />
              <span>Start Monitoring</span>
            </>
          )}
        </button>
      </div>

      <AnimatePresence>
        {isMonitoring && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mt-6 space-y-4"
          >
            {/* Status Bar */}
            <div className="relative h-2 bg-cyber-900 rounded-full overflow-hidden">
              <motion.div
                className="absolute inset-y-0 left-0 bg-gradient-to-r from-cyber-blue to-cyber-green"
                animate={{
                  x: ['-100%', '100%'],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "linear"
                }}
                style={{ width: '50%' }}
              />
            </div>

            {/* Live Status */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyber-green animate-pulse" />
                <span className="text-sm text-gray-300">
                  {scanMessage || 'Monitoring active...'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Bell className="w-3 h-3 text-cyber-amber" />
                <span className="text-xs text-gray-500">Alerts: 3</span>
              </div>
            </div>

            {/* Live Feed Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-2 bg-cyber-900 rounded-lg">
                <p className="text-sm font-bold text-cyber-blue">1.2k</p>
                <p className="text-xs text-gray-600">Sources</p>
              </div>
              <div className="text-center p-2 bg-cyber-900 rounded-lg">
                <p className="text-sm font-bold text-cyber-green">47</p>
                <p className="text-xs text-gray-600">Active</p>
              </div>
              <div className="text-center p-2 bg-cyber-900 rounded-lg">
                <p className="text-sm font-bold text-cyber-amber">12</p>
                <p className="text-xs text-gray-600">Threats</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default MonitoringToggle;