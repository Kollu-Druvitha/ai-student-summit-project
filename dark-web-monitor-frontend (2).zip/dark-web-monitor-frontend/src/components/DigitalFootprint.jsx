import React from 'react';
import { Globe, User, MapPin, Mail, Phone, Link } from 'lucide-react';
import { motion } from 'framer-motion';

const DigitalFootprint = () => {
  const footprintData = [
    { type: 'Email Addresses', count: 3, risk: 'medium' },
    { type: 'Phone Numbers', count: 1, risk: 'low' },
    { type: 'Social Profiles', count: 4, risk: 'low' },
    { type: 'Data Breaches', count: 2, risk: 'high' },
    { type: 'Public Records', count: 5, risk: 'low' },
    { type: 'Associated Accounts', count: 8, risk: 'medium' },
  ];

  const getRiskColor = (risk) => {
    switch(risk) {
      case 'high': return 'text-cyber-red';
      case 'medium': return 'text-cyber-amber';
      default: return 'text-cyber-green';
    }
  };

  const exposureScore = 65; // 0-100

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.8 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <Globe className="w-5 h-5 text-cyber-blue" />
        Digital Footprint Score
      </h3>

      {/* Score Circle */}
      <div className="flex items-center gap-6 mb-6">
        <div className="relative w-24 h-24">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="48"
              cy="48"
              r="42"
              stroke="currentColor"
              strokeWidth="4"
              fill="none"
              className="text-cyber-700"
            />
            <circle
              cx="48"
              cy="48"
              r="42"
              stroke="currentColor"
              strokeWidth="4"
              fill="none"
              strokeDasharray={2 * Math.PI * 42}
              strokeDashoffset={2 * Math.PI * 42 * (1 - exposureScore / 100)}
              className="text-cyber-blue"
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-white">{exposureScore}</span>
          </div>
        </div>
        
        <div>
          <p className="text-sm text-gray-400">Exposure Score</p>
          <p className="text-lg font-bold text-cyber-blue">Moderate Risk</p>
          <p className="text-xs text-gray-500 mt-1">Based on 23 data points</p>
        </div>
      </div>

      {/* Footprint Grid */}
      <div className="grid grid-cols-2 gap-3">
        {footprintData.map((item, index) => (
          <div key={index} className="p-3 bg-cyber-900 rounded-lg">
            <p className="text-sm text-gray-400">{item.type}</p>
            <div className="flex items-center justify-between mt-1">
              <span className="text-lg font-bold text-white">{item.count}</span>
              <span className={`text-xs ${getRiskColor(item.risk)}`}>
                {item.risk}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Action Button */}
      <button className="w-full mt-4 py-2 text-sm text-cyber-blue border border-cyber-blue/30 rounded-lg
                         hover:bg-cyber-blue/10 transition-colors">
        View Full Digital Profile
      </button>
    </motion.div>
  );
};

export default DigitalFootprint;