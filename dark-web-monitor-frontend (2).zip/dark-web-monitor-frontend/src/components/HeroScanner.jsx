import React, { useState } from 'react';
import { Search, Loader2, Shield, AlertTriangle, CheckCircle, Mail } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const HeroScanner = ({ onScan, loading, result }) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    setError('');
    onScan(email);
  };

  const getRiskBadge = () => {
    if (!result) return null;
    
    const level = result.risk_level?.toLowerCase();
    const classes = {
      low: 'badge-low',
      medium: 'badge-medium',
      high: 'badge-high'
    };
    
    return (
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className={`risk-badge ${classes[level] || ''} flex items-center gap-2`}
      >
        {level === 'high' && <AlertTriangle size={14} />}
        {level === 'medium' && <AlertTriangle size={14} />}
        {level === 'low' && <CheckCircle size={14} />}
        <span className="font-medium">{result.risk_level} RISK</span>
        <span className="text-xs opacity-75">({result.risk_score}/100)</span>
      </motion.div>
    );
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.1 }}
      className="glass-premium p-6 md:p-8"
    >
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
            <Shield className="w-6 h-6 text-cyber-blue" />
            Enterprise Breach Scanner
          </h2>
          <p className="text-gray-400 text-sm">
            Check if your credentials have been exposed in known data breaches
          </p>
        </div>
        {result && getRiskBadge()}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Mail className="absolute left-4 top-3.5 text-gray-500" size={18} />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter corporate email address..."
              className="cyber-input w-full pl-12"
              disabled={loading}
            />
            <AnimatePresence>
              {loading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute right-4 top-3"
                >
                  <Loader2 className="animate-spin text-cyber-blue" size={20} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loading}
            className="cyber-button md:w-auto w-full flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Scanning Intelligence...
              </>
            ) : (
              <>
                <Search size={18} />
                Initiate Security Scan
              </>
            )}
          </motion.button>
        </div>
        
        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-cyber-red text-sm flex items-center gap-2 bg-cyber-red/10 p-3 rounded-lg border border-cyber-red/30"
            >
              <AlertTriangle size={14} />
              {error}
            </motion.p>
          )}
        </AnimatePresence>
      </form>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 pt-6 border-t border-cyber-700">
        {[
          { label: 'Breaches Analyzed', value: '12.5B', icon: Shield, color: 'blue' },
          { label: 'Active Threats', value: '1,847', icon: AlertTriangle, color: 'red' },
          { label: 'Daily Scans', value: '2.4M', icon: Search, color: 'green' },
          { label: 'Protected Accounts', value: '50K+', icon: CheckCircle, color: 'purple' },
        ].map((stat, index) => (
          <div key={index} className="text-center p-3 bg-cyber-900/50 rounded-lg">
            <stat.icon className={`w-4 h-4 text-cyber-${stat.color} mx-auto mb-2`} />
            <p className="text-lg font-bold text-white">{stat.value}</p>
            <p className="text-xs text-gray-500">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Security Note */}
      <div className="mt-4 text-center">
        <p className="text-xs text-gray-600 flex items-center justify-center gap-2">
          <Shield size={12} />
          Enterprise-grade encryption • Real-time monitoring • SOC 2 Type II compliant
        </p>
      </div>
    </motion.div>
  );
};

export default HeroScanner;