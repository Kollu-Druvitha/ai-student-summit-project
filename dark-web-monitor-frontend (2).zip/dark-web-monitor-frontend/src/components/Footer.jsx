import React from 'react';
import { Shield, Github, Twitter, Linkedin, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="glass-premium mx-4 md:mx-6 lg:mx-8 mb-4 px-6 py-4">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyber-blue" />
          <span className="text-xs text-gray-500">
            © 2024 Dark Web Monitor • Enterprise Security Suite v3.0
          </span>
        </div>
        
        <div className="flex items-center gap-6">
          {/* Status */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="w-2 h-2 bg-cyber-green rounded-full animate-pulse"></div>
              <div className="absolute inset-0 bg-cyber-green/50 blur-sm"></div>
            </div>
            <span className="text-xs text-gray-500">All Systems Operational</span>
          </div>

          {/* Version */}
          <span className="text-xs text-cyber-blue bg-cyber-blue/10 px-2 py-1 rounded">
            v3.0.0
          </span>

          {/* Social Links */}
          <div className="flex items-center gap-3">
            <a href="#" className="text-gray-500 hover:text-cyber-blue transition-colors">
              <Github className="w-4 h-4" />
            </a>
            <a href="#" className="text-gray-500 hover:text-cyber-blue transition-colors">
              <Twitter className="w-4 h-4" />
            </a>
            <a href="#" className="text-gray-500 hover:text-cyber-blue transition-colors">
              <Linkedin className="w-4 h-4" />
            </a>
            <a href="#" className="text-gray-500 hover:text-cyber-blue transition-colors">
              <Mail className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Links */}
      <div className="flex flex-wrap justify-center gap-4 mt-4 pt-4 border-t border-cyber-700/50">
        <a href="#" className="text-xs text-gray-600 hover:text-cyber-blue transition-colors">
          Privacy Policy
        </a>
        <a href="#" className="text-xs text-gray-600 hover:text-cyber-blue transition-colors">
          Terms of Service
        </a>
        <a href="#" className="text-xs text-gray-600 hover:text-cyber-blue transition-colors">
          Security
        </a>
        <a href="#" className="text-xs text-gray-600 hover:text-cyber-blue transition-colors">
          Status
        </a>
        <a href="#" className="text-xs text-gray-600 hover:text-cyber-blue transition-colors">
          Documentation
        </a>
      </div>
    </footer>
  );
};

export default Footer;