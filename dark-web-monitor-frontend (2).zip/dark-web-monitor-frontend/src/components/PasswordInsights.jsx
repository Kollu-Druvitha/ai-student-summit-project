import React from 'react';
import { Key, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { passwordInsights } from '../lib/mockData';

const PasswordInsights = () => {
  const insights = passwordInsights;

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.4 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <Key className="w-5 h-5 text-cyber-blue" />
        Password Strength Insights
      </h3>

      <div className="space-y-4">
        {/* Metrics */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-3 bg-cyber-900 rounded-lg">
            <p className="text-2xl font-bold text-cyber-red">{insights.weakPasswords}</p>
            <p className="text-xs text-gray-500">Weak</p>
          </div>
          <div className="text-center p-3 bg-cyber-900 rounded-lg">
            <p className="text-2xl font-bold text-cyber-amber">{insights.reusedPasswords}</p>
            <p className="text-xs text-gray-500">Reused</p>
          </div>
          <div className="text-center p-3 bg-cyber-900 rounded-lg">
            <p className="text-2xl font-bold text-cyber-green">{insights.strongPasswords}</p>
            <p className="text-xs text-gray-500">Strong</p>
          </div>
        </div>

        {/* Password Health Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Password Health</span>
            <span className="text-cyber-green">
              {Math.round((insights.strongPasswords / 
                (insights.weakPasswords + insights.reusedPasswords + insights.strongPasswords)) * 100)}%
            </span>
          </div>
          <div className="h-2 bg-cyber-900 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ 
                width: `${(insights.strongPasswords / 
                  (insights.weakPasswords + insights.reusedPasswords + insights.strongPasswords)) * 100}%` 
              }}
              transition={{ duration: 1 }}
              className="h-full bg-gradient-to-r from-cyber-blue to-cyber-green"
            />
          </div>
        </div>

        {/* Recommendation */}
        <div className="mt-4 p-4 bg-cyber-900/50 border border-cyber-700 rounded-xl">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-cyber-amber flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-300">{insights.recommendation}</p>
              <button className="mt-2 text-xs text-cyber-blue hover:text-cyber-blue/80 flex items-center gap-1">
                <RefreshCw size={12} />
                Update Now
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PasswordInsights;