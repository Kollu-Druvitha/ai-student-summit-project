import React from 'react';
import { Shield, AlertTriangle, Activity, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const OverviewDashboard = ({ result, isMonitoring }) => {
  const securityScore = result?.risk_score !== undefined ? 100 - result.risk_score : 85;
  const breachCount = result?.breach_count || 0;
  
  const getScoreColor = () => {
    if (securityScore >= 80) return '#00FF9C';
    if (securityScore >= 60) return '#FFB347';
    return '#FF4D6D';
  };

  const metrics = [
    {
      icon: Shield,
      label: 'Security Health',
      value: `${securityScore}%`,
      color: getScoreColor(),
      change: '+5%',
    },
    {
      icon: AlertTriangle,
      label: 'Breaches Detected',
      value: breachCount,
      color: breachCount > 0 ? '#FF4D6D' : '#00FF9C',
      change: breachCount > 0 ? 'Critical' : 'Safe',
    },
    {
      icon: Activity,
      label: 'Risk Level',
      value: result?.risk_level || 'LOW',
      color: result?.risk_level === 'HIGH' ? '#FF4D6D' : 
             result?.risk_level === 'MEDIUM' ? '#FFB347' : '#00FF9C',
      change: 'Active',
    },
    {
      icon: Clock,
      label: 'Last Scan',
      value: new Date().toLocaleTimeString(),
      color: '#00C2FF',
      change: 'Real-time',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <motion.div
          key={index}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: index * 0.1 }}
          className="metric-card"
        >
          <div className="flex items-start justify-between">
            <div className="p-2 rounded-xl" style={{ backgroundColor: `${metric.color}10` }}>
              <metric.icon className="w-5 h-5" style={{ color: metric.color }} />
            </div>
            <span className="text-xs font-mono" style={{ color: metric.color }}>
              {metric.change}
            </span>
          </div>
          
          <div className="mt-4">
            <p className="text-2xl font-bold text-white">{metric.value}</p>
            <p className="text-sm text-gray-500 mt-1">{metric.label}</p>
          </div>

          {index === 0 && (
            <div className="mt-4 h-1 bg-cyber-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${securityScore}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-full rounded-full"
                style={{ backgroundColor: getScoreColor() }}
              />
            </div>
          )}
        </motion.div>
      ))}

      {/* Monitoring Status */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="metric-card col-span-full flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className={`w-3 h-3 ${isMonitoring ? 'bg-cyber-green' : 'bg-gray-500'} rounded-full animate-pulse`}></div>
            <div className={`absolute inset-0 ${isMonitoring ? 'bg-cyber-green' : 'bg-gray-500'} blur-sm animate-pulse`}></div>
          </div>
          <div>
            <p className="text-sm text-gray-300">
              {isMonitoring ? 'Monitoring active' : 'Monitoring paused'}
            </p>
            <p className="text-xs text-gray-500">
              {isMonitoring ? 'Scanning 1,847 intelligence feeds...' : 'Click "Start Monitoring" to begin'}
            </p>
          </div>
        </div>
        
        <div className="flex gap-4">
          <div className="text-right">
            <p className="text-xs text-gray-500">Threats Blocked</p>
            <p className="text-lg font-bold text-cyber-green">1,234</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500">Uptime</p>
            <p className="text-lg font-bold text-cyber-blue">99.9%</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default OverviewDashboard;