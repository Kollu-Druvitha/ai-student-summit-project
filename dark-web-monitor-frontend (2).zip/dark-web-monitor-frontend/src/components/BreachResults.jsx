import React from 'react';
import { AlertTriangle, Database, Calendar, Shield, Globe, Lock, Mail, Phone, CreditCard } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const BreachResults = ({ result }) => {
  if (!result || !result.found_in_breaches) return null;

  const getDataIcon = (dataType) => {
    const type = dataType.toLowerCase();
    if (type.includes('email')) return <Mail size={14} />;
    if (type.includes('phone')) return <Phone size={14} />;
    if (type.includes('credit') || type.includes('card')) return <CreditCard size={14} />;
    return <Lock size={14} />;
  };

  const getSeverityColor = (dataLeaked) => {
    const sensitive = ['credit_card', 'ssn', 'password', 'address'];
    const hasSensitive = dataLeaked.some(item => 
      sensitive.some(s => item.toLowerCase().includes(s))
    );
    return hasSensitive ? 'border-cyber-red/30 bg-cyber-red/5' : 'border-cyber-amber/30 bg-cyber-amber/5';
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="glass-premium p-6"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-cyber-red/10 rounded-lg">
          <AlertTriangle className="w-5 h-5 text-cyber-red" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">Data Breaches Detected</h3>
          <p className="text-sm text-gray-400">
            Found in {result.breach_count} security incident{result.breach_count > 1 ? 's' : ''}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <AnimatePresence>
          {result.breaches.map((breach, index) => (
            <motion.div
              key={index}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`p-5 rounded-lg border ${getSeverityColor(breach.data_leaked)}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-cyber-blue" />
                  <div>
                    <h4 className="font-semibold text-white">{breach.breach_name}</h4>
                    <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                      <Calendar size={12} />
                      {new Date(breach.breach_date).toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </div>
                  </div>
                </div>
                <span className="text-xs px-2 py-1 rounded bg-cyber-red/10 text-cyber-red border border-cyber-red/30">
                  Confirmed
                </span>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-gray-400 mb-2">Exposed Data:</p>
                <div className="flex flex-wrap gap-2">
                  {breach.data_leaked.map((data, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-1.5 text-xs bg-cyber-900 
                               text-gray-300 px-3 py-1.5 rounded-full border border-cyber-700"
                    >
                      {getDataIcon(data)}
                      {data}
                    </span>
                  ))}
                </div>
              </div>

              {/* Impact Indicator */}
              <div className="mt-4 pt-4 border-t border-cyber-700">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Severity Impact</span>
                  <span className="text-cyber-red font-medium">
                    {breach.data_leaked.some(d => d.includes('credit') || d.includes('ssn')) 
                      ? 'Critical' 
                      : breach.data_leaked.includes('password') 
                        ? 'High' 
                        : 'Medium'}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Security Alert Banner */}
      <div className="mt-6 p-4 bg-cyber-blue/5 border border-cyber-blue/20 rounded-lg">
        <p className="text-sm text-gray-300 flex items-start gap-2">
          <Shield className="w-4 h-4 text-cyber-blue mt-0.5 flex-shrink-0" />
          <span>
            <strong className="text-cyber-blue">Immediate Action Required:</strong> Your exposed credentials 
            are being actively monitored. Review the AI Security Advisor below for protective measures.
          </span>
        </p>
      </div>
    </motion.div>
  );
};

export default BreachResults;