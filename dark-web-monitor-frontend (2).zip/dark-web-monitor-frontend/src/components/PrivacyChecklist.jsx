import React, { useState } from 'react';
import { CheckSquare, Square, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { privacyChecklist } from '../lib/mockData';

const PrivacyChecklist = () => {
  const [checklist, setChecklist] = useState(privacyChecklist);

  const toggleItem = (id) => {
    setChecklist(checklist.map(item =>
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const progress = (checklist.filter(item => item.completed).length / checklist.length) * 100;

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.6 }}
      className="glass-premium p-6"
    >
      <h3 className="section-header">
        <CheckSquare className="w-5 h-5 text-cyber-blue" />
        Privacy Improvement Checklist
      </h3>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-gray-400">Security Setup</span>
          <span className="text-cyber-blue">{Math.round(progress)}% Complete</span>
        </div>
        <div className="h-2 bg-cyber-900 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1 }}
            className="h-full bg-gradient-to-r from-cyber-blue to-cyber-green"
          />
        </div>
      </div>

      {/* Checklist Items */}
      <div className="space-y-3">
        {checklist.map((item) => (
          <motion.div
            key={item.id}
            whileHover={{ x: 4 }}
            className="flex items-start gap-3 p-2 rounded-lg hover:bg-cyber-800/50 transition-colors cursor-pointer"
            onClick={() => toggleItem(item.id)}
          >
            {item.completed ? (
              <CheckSquare className="w-5 h-5 text-cyber-green flex-shrink-0" />
            ) : (
              <Square className="w-5 h-5 text-gray-600 flex-shrink-0" />
            )}
            <div className="flex-1">
              <p className={`text-sm ${item.completed ? 'text-gray-500 line-through' : 'text-gray-300'}`}>
                {item.task}
              </p>
              {item.critical && !item.completed && (
                <div className="flex items-center gap-1 mt-1">
                  <AlertCircle className="w-3 h-3 text-cyber-red" />
                  <span className="text-xs text-cyber-red">Critical action required</span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Action Button */}
      <button className="w-full mt-4 py-2 text-sm text-cyber-blue border border-cyber-blue/30 rounded-lg
                         hover:bg-cyber-blue/10 transition-colors">
        Complete All Recommended Actions
      </button>
    </motion.div>
  );
};

export default PrivacyChecklist;